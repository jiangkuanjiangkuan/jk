package jk_domain;

import java.io.IOException;

import org.itheima.game.utils.DrawUtils;

import jk_busness.Blockable;
import jk_busness.Destroyable;
import jk_busness.Hitable;

public class Wall extends Element implements Blockable,Hitable,Destroyable{
      
      private int blood = 3;
      public Wall(int x,int y) {
    	 super(x, y);
    	 
		try {
			int[] size = DrawUtils.getSize("res/img/wall.gif");
			 width = size[0];
			 height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
      //成员方法
      public void draw() {
    	  try {
			DrawUtils.draw("res/img/wall.gif", x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
      //显示反应情况：挨打
    @Override
    public Blast showAttack() {
    	// TODO Auto-generated method stub
    	blood--;
    	return new Blast(this,true);
    }
    //销毁砖墙
	@Override
	public boolean isDestory() {
		// TODO Auto-generated method stub
		return blood <= 0;
	}
    //销毁时响应的动作
	@Override
	public Blast showDestory() {
		// TODO Auto-generated method stub
		return new Blast(this);
	}
}
