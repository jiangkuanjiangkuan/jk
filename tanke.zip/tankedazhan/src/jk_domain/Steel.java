package jk_domain;

import java.io.IOException;

import org.itheima.game.utils.DrawUtils;

import jk_busness.Blockable;
import jk_busness.Destroyable;
import jk_busness.Hitable;
//铁墙
public class Steel extends Element implements Blockable,Hitable,Destroyable{
	
      private int blood = 5;  
	
      public Steel(int x,int y) {
    	  super(x, y);
    	  
		try {
			int[] size = DrawUtils.getSize("res/img/steel.gif");
			width = size[0];
			height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
      }
      
      //成员方法
      public void draw() {
    	  try {
			DrawUtils.draw("res/img/steel.gif", x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      }
      //挨打后
      public Blast showAttack() {
    	  blood--;
  		return new Blast(this,true);
  	}

	@Override
	public boolean isDestory() {
		// TODO Auto-generated method stub
		return blood <= 0;
	}

	@Override
	public Blast showDestory() {
		// TODO Auto-generated method stub
		return new Blast(this);
	}
}
