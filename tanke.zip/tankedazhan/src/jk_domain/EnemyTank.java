package jk_domain;

import java.io.IOException;
import java.nio.channels.NonWritableChannelException;
import java.util.Random;

import org.itheima.game.utils.CollisionUtils;
import org.itheima.game.utils.DrawUtils;
import jk_busness.Blockable;
import jk_busness.Moveable;
import jk_game.config;

public class EnemyTank extends Element implements Moveable{
 
    //血量
	private int blood;
	//攻击力
	private int power;
	//移动方向
	private Direction direction = Direction.UP;
	//移动速度
	private int speed = 3;
	//记录最后一颗子弹的发射时间
	private long LastShotTime;
	//记录坦克不能移动的方向
	private Direction badDirection;
	//最小间隙
	private int badSpeed;
	
	
	public EnemyTank(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
		try {
			int[] size = DrawUtils.getSize("res\\img\\enemy_u.gif");
			width = size[0];
			height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
     //绘制坦克 
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		String res = "";
		switch (direction) {
		case UP:
			res = "res\\img\\enemy_u.gif";
			break;
		case DOWN:
			res = "res\\img\\enemy_d.gif";
			break;
		case LEFT:
			res = "res\\img\\enemy_l.gif";
			break;
		case RIGHT:
			res = "res\\img\\enemy_r.gif";
			break;
		default:
			break;
		}
		try {
			DrawUtils.draw(res, x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//取随机数
	public Direction getRandomDirection() {
		int num = new Random().nextInt(4);
		switch (num) {
		case 0:
		//case 4:
			return Direction.UP;
		case 1:
			return Direction.DOWN;
		case 2:
			return Direction.LEFT;
		case 3:
			return Direction.RIGHT;
		}
		return Direction.UP;
	}
	
	//记录坦克的移动
	public void move() {
		
		if(direction == badDirection) {
			//
			switch (direction) {
			case UP:
				y -= badSpeed;
				break;
			case DOWN:
				y += badSpeed;
				break;
			case LEFT:
				x -= badSpeed;
				break;
			case RIGHT:
				x += badSpeed;
				break;
			default:
				break;
			}
			//不能移动，随机获取方向
			
			return;
		}
		
		switch (direction) {
		case UP:
			y -= speed;
			break;
		case DOWN:
			y += speed;
			break;
		case LEFT:
			x -= speed;
			break;
		case RIGHT:
			x += speed;
			break;
		default:
			break;
		}
		
		if (x<0) {
			x=0;
			direction = getRandomDirection();
		}
		if (y<0) {
			y=0;
			direction = getRandomDirection();
		}
		if (x>config.WIDTH-64) {
			x=config.WIDTH-64;
			direction = getRandomDirection();
		}
		if (y>config.HEIGHT-64) {
			y=config.HEIGHT-64;
			direction = getRandomDirection();
		}
		
	}
	//发射子弹
    public ZiDan shot() {
		// TODO Auto-generated method stub
		long nowTime = System.currentTimeMillis();
		if(nowTime - LastShotTime < 800) {
			return null;
		}else {
			LastShotTime = nowTime;
			//return new ZiDan(this);
			return null;
		}	
	}
	//获取坦克移动方向
    public Direction getDirection() {
		return direction;
	}
	//校验坦克和铁墙是否碰撞上
	public boolean checkHit(Blockable blockable) {
		// TODO Auto-generated method stub
		Element e = (Element)blockable;
    	int x1 = e.x;
    	int y1 = e.y;
    	int w1 = e.width;
    	int h1 = e.height;
    	//
    	int x2 = x;
    	int y2 = y;
    	
    	switch (direction) {
		case UP:
			y2 -= speed;
			break;
		case DOWN:
			y2 += speed;
			break;
		case LEFT:
			x2 -= speed;
			break;
		case RIGHT:
			x2 += speed;
			break;
		default:
			break;
		}
    	boolean flag = CollisionUtils.isCollsionWithRect(x1, y1, w1, h1, x2, y2, width, height);
		if (flag) {
			badDirection= direction;
			switch (direction) {
			case UP:
				badSpeed = y - y1 -h1;
				//y2 -= speed;
				break;
			case DOWN:
				badSpeed = y1 - y - height;
				break;
			case LEFT:
				badSpeed = x - x1 - w1;
				break;
			case RIGHT:
				badSpeed = x1 - x - width;
				break;
			default:
				break;
			}
		}else {
			badDirection = null;
		}	
    	return flag;	
	}
	
}
