package jk_domain;

public enum Direction {
     UP,DOWN,LEFT,RIGHT;
}
