package jk_domain;

import java.io.IOException;

import org.itheima.game.utils.DrawUtils;


public class Grass extends Element{

	public Grass(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
		try {
			int[] size = DrawUtils.getSize("res/img/grass.gif");
			width = size[0];
			height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		try {
			DrawUtils.draw("res/img/grass.gif", x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public int getOrder() {
		return 1;
	}

}
