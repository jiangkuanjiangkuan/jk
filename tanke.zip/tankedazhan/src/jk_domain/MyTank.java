package jk_domain;

import java.io.IOException;

import org.itheima.game.utils.CollisionUtils;
import org.itheima.game.utils.DrawUtils;
import jk_busness.Blockable;
import jk_busness.Moveable;
import jk_game.config;

public class MyTank extends Element implements Moveable{
 
    //血量
	private int blood;
	//攻击力
	private int power;
	//移动方向
	private Direction direction = Direction.UP;
	//移动速度
	private int speed = 20;
	//记录最后一颗子弹的发射时间
	private long LastShotTime;
	//记录坦克不能移动的方向
	private Direction badDirection;
	//最小间隙
	private int badSpeed;
	
	
	public MyTank(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
		try {
			int[] size = DrawUtils.getSize("res\\img\\tank_u.gif");
			width = size[0];
			height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
     //绘制坦克 
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		String res = "";
		switch (direction) {
		case UP:
			res = "res\\img\\tank_u.gif";
			break;
		case DOWN:
			res = "res\\img\\tank_d.gif";
			break;
		case LEFT:
			res = "res\\img\\tank_l.gif";
			break;
		case RIGHT:
			res = "res\\img\\tank_r.gif";
			break;
		default:
			break;
		}
		try {
			DrawUtils.draw(res, x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//记录坦克的移动
	public void move(Direction direction) {
		
		if(direction == badDirection) {
			//
			switch (direction) {
			case UP:
				y -= badSpeed;
				break;
			case DOWN:
				y += badSpeed;
				break;
			case LEFT:
				x -= badSpeed;
				break;
			case RIGHT:
				x += badSpeed;
				break;
			default:
				break;
			}
			return;
		}
		
		if (this.direction != direction) {
			this.direction = direction;
			return;
		}
		
		switch (direction) {
		case UP:
			y -= speed;
			break;
		case DOWN:
			y += speed;
			break;
		case LEFT:
			x -= speed;
			break;
		case RIGHT:
			x += speed;
			break;
		default:
			break;
		}
		
		if (x<0) {
			x=0;
		}
		if (y<0) {
			y=0;
		}
		if (x>config.WIDTH-64) {
			x=config.WIDTH-64;
		}
		if (y>config.HEIGHT-64) {
			y=config.HEIGHT-64;
		}
		
	}
	//发射子弹
    public ZiDan shot() {
		// TODO Auto-generated method stub
		long nowTime = System.currentTimeMillis();
		if(nowTime - LastShotTime < 300) {
			return null;
		}else {
			LastShotTime = nowTime;
			return new ZiDan(this);
		}	
	}
	//获取坦克移动方向
    public Direction getDirection() {
		return direction;
	}
	//校验坦克和铁墙是否碰撞上
	public boolean checkHit(Blockable blockable) {
		// TODO Auto-generated method stub
		Element e = (Element)blockable;
    	int x1 = e.x;
    	int y1 = e.y;
    	int w1 = e.width;
    	int h1 = e.height;
    	//
    	int x2 = x;
    	int y2 = y;
    	
    	switch (direction) {
		case UP:
			y2 -= speed;
			break;
		case DOWN:
			y2 += speed;
			break;
		case LEFT:
			x2 -= speed;
			break;
		case RIGHT:
			x2 += speed;
			break;
		default:
			break;
		}
    	boolean flag = CollisionUtils.isCollsionWithRect(x1, y1, w1, h1, x2, y2, width, height);
		if (flag) {
			badDirection= direction;
			switch (direction) {
			case UP:
				badSpeed = y - y1 -h1;
				//y2 -= speed;
				break;
			case DOWN:
				badSpeed = y1 - y - height;
				break;
			case LEFT:
				badSpeed = x - x1 - w1;
				break;
			case RIGHT:
				badSpeed = x1 - x - width;
				break;
			default:
				break;
			}
		}else {
			badDirection = null;
		}	
    	return flag;	
	}
	
}
