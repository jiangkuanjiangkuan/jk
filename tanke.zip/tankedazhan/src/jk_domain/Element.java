package jk_domain;

//父类，表示所有元素

public abstract class Element {
	 protected int x;
	 protected int y;
     
	 protected int width;
	 protected int height;
	 
	 public Element() {
		 
	 }
     
     public Element(int x,int y) {
   	  this.x=x;
   	  this.y=y;
     }
     //绘制元素
     public abstract void draw();

	public int getOrder() {
		// TODO Auto-generated method stub
		return 0;
	}

	public Blast showAttack() {
		// TODO Auto-generated method stub
		return null;
	}
}
