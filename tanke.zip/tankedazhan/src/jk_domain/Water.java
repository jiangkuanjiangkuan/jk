package jk_domain;

import java.io.IOException;

import org.itheima.game.utils.DrawUtils;

import jk_busness.Blockable;

public class Water extends Element implements Blockable{

	public Water(int x, int y) {
		super(x, y);
		// TODO Auto-generated constructor stub
		try {
			int[] size = DrawUtils.getSize("res/img/water.gif");
			 width = size[0];
			 height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		try {
			DrawUtils.draw("res/img/water.gif", x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
