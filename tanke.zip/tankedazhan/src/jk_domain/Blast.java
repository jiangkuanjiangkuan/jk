package jk_domain;

import java.io.IOException;

import javax.print.attribute.Size2DSyntax;

import org.itheima.game.utils.DrawUtils;
import org.itheima.game.utils.SoundUtils;

import jk_busness.Destroyable;
import jk_busness.Hitable;

//爆炸物
public class Blast extends Element implements Destroyable{
    //属性
	private String[] arr = {"res/img/blast_1.gif", "res/img/blast_2.gif", "res/img/blast_3.gif","res/img/blast_4.gif","res/img/blast_5.gif",
			"res/img/blast_6.gif","res/img/blast_7.gif","res/img/blast_8.gif"};
	
	private int i;
	
	//记录是否销毁爆炸物
	private boolean isDestory;
	//
    public Blast(Hitable hit) {
    	this(hit, false);
    	try {
			SoundUtils.play("res/snd/blast.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    
    public Blast(Hitable hit,boolean flag) {//flag:true 1-4    false: 1-8
    	Element e1 = (Element)hit;
    	int x1 = e1.x;
    	int y1 = e1.y;
    	int w1 = e1.width;
    	int h1 = e1.height;
    	
    	//
    	try {
			int[] size = DrawUtils.getSize("res/img/blast_1.gif");
			width = size[0];
			height = size[1];
			
			x = x1 + (w1-width)/2;
			y = y1 + (h1 - height)/2;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	if (flag) {
    		arr = new String[]{"res/img/blast_1.gif", "res/img/blast_2.gif", "res/img/blast_3.gif","res/img/blast_4.gif"};
    		try {
				SoundUtils.play("res/snd/hit.wav");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    		
		}
	}
	//
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		String res = arr[i++];
		if(i >= arr.length) {
			i=0;
			//销毁即可
			isDestory = true;
		}
		try {
			DrawUtils.draw(res, x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//获取爆炸物的状态，
	public boolean isDestory() {
		return  isDestory;
	}
	//销毁时，绘制爆炸物
	@Override
	public Blast showDestory() {
		// TODO Auto-generated method stub
		return null;
	}

}
