package jk_domain;

import java.io.IOException;

import org.itheima.game.utils.CollisionUtils;
import org.itheima.game.utils.DrawUtils;
import org.itheima.game.utils.SoundUtils;

import jk_busness.Attackable;
import jk_busness.Destroyable;
import jk_busness.Hitable;
import jk_game.config;

public class ZiDan extends Element implements Attackable,Destroyable{
	private  Direction direction;
	private  int speed = 6;
	//子弹坐标依赖坦克坐标
	public ZiDan(MyTank mt) {
		// TODO Auto-generay;
		super();
		
		int tankX = mt.x;
		int tankY = mt.y;
		int tankWidth = mt.width;
		int tankHeight = mt.height;
		this.direction = mt.getDirection();
		
		try {
			int[] size = DrawUtils.getSize("res\\img\\bullet_u.gif");
			width = size[0];
			height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		switch (direction) {
		case UP:
			x = Math.round(tankX+(tankWidth-width)/2f);
			y = Math.round(tankY-height/2f);
			break;
		case DOWN:
			x = Math.round(tankX+(tankWidth-width)/2f);
			y = Math.round(tankY+tankHeight-height/2f);
			break;
		case LEFT:
			x = tankX-width;                 //图有问题
			y = Math.round(tankY+(tankHeight-height)/2f);
			break;
		case RIGHT:
			x = Math.round(tankX+tankWidth-width/2f);
			y = Math.round(tankY+(tankHeight-height)/2f);
			break;

		default:
			break;
		}
		//声音
		try {
			SoundUtils.play("res\\snd\\fire.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ZiDan(EnemyTank et) {
		// TODO Auto-generay;
		super();
		
		int tankX = et.x;
		int tankY = et.y;
		int tankWidth = et.width;
		int tankHeight = et.height;
		this.direction = et.getDirection();
		
		try {
			int[] size = DrawUtils.getSize("res\\img\\bullet_u.gif");
			width = size[0];
			height = size[1];
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		switch (direction) {
		case UP:
			x = Math.round(tankX+(tankWidth-width)/2f);
			y = Math.round(tankY-height/2f);
			break;
		case DOWN:
			x = Math.round(tankX+(tankWidth-width)/2f);
			y = Math.round(tankY+tankHeight-height/2f);
			break;
		case LEFT:
			x = tankX-width;                 //图有问题
			y = Math.round(tankY+(tankHeight-height)/2f);
			break;
		case RIGHT:
			x = Math.round(tankX+tankWidth-width/2f);
			y = Math.round(tankY+(tankHeight-height)/2f);
			break;

		default:
			break;
		}
		//声音
		try {
			SoundUtils.play("res\\snd\\fire.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    //绘制子弹
	@Override
	public void draw() {
		// TODO Auto-generated method stub
		String res = "";
		switch (direction) {
		case UP:
			res = "res\\img\\bullet_u.gif";
			y -= speed;
			break;
		case DOWN:
			res = "res\\img\\bullet_d.gif";
			y += speed;
			break;
		case LEFT:
			res = "res\\img\\bullet_l.gif";  
			x -= speed;
			break;
		case RIGHT:
			res = "res\\img\\bullet_r.gif";
			x += speed;
			break;
		default:
			break;
		}
		try {
			DrawUtils.draw(res, x, y);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	//
	public boolean isDestroy() {
		//判断子弹是否销毁
		if(x<0-width || x>config.WIDTH || y<0-height || y>config.HEIGHT) {
			return true;
		}
		return false;
		
	}
	//子弹与铁墙
	public boolean checkAttack(Hitable hit) {
		Element e1 = (Element)hit;
		
		int x1 = e1.x;
    	int y1 = e1.y;
    	int w1 = e1.width;
    	int h1 = e1.height;
    	
    	return CollisionUtils.isCollsionWithRect(x1, y1, w1, h1, x, y, width, height) ;
	}
	
	// 子弹销毁时的反应
	@Override
	public Blast showDestory() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean isDestory() {
		// TODO Auto-generated method stub
		return false;
	}

}
