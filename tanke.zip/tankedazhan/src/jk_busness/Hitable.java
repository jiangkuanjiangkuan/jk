package jk_busness;

import jk_domain.Blast;

public interface Hitable {
	
	     Blast showAttack();
	
}
