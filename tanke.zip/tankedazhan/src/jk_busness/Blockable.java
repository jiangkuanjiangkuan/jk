package jk_busness;

public interface Blockable {
      
}
