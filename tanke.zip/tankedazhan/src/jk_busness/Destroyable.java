package jk_busness;

import jk_domain.Blast;

public interface Destroyable {
	/**
	 * 判断是否需要销毁
	 * @return
	 */
	boolean isDestory();
	
	/**
	 * 销毁的时候, 绘制爆炸物
	 * @return
	 */
	Blast showDestory();
}
