package jk_busness;

public interface Attackable {
	/**
	 * 校验具有攻击能力的事物, 和 具有挨打能力的事物, 是否碰撞到一起
	 * @param hit
	 * @return
	 */
	boolean checkAttack(Hitable hit);
}
