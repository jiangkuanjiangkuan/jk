package jk_busness;

public interface Moveable {
     boolean checkHit(Blockable blockable);
}
