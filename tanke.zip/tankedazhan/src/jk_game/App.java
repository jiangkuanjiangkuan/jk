package jk_game;

public class App {
      public static void main(String[] args) {
    	  
    	  GameWindow gw = new GameWindow(config.TITLE,config.WIDTH,config.HEIGHT,config.FPS);
    	  
    	  gw.start();
    	 
    	   
  }
}
