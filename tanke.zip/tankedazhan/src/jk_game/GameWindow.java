package jk_game;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.rmi.CORBA.ValueHandlerMultiFormat;
import javax.security.auth.Destroyable;

import org.itheima.game.Window;
import org.itheima.game.utils.DrawUtils;
import org.itheima.game.utils.SoundUtils;
import org.lwjgl.input.Keyboard;

import jk_busness.Attackable;
import jk_busness.Blockable;
import jk_busness.Hitable;
import jk_busness.Moveable;
import jk_domain.Blast;
import jk_domain.Direction;
import jk_domain.Element;
import jk_domain.EnemyTank;
import jk_domain.Grass;
import jk_domain.MyTank;
import jk_domain.Steel;
import jk_domain.Wall;
import jk_domain.Water;
import jk_domain.ZiDan;

public class GameWindow extends Window{
	
	//定义集合（砖）
	CopyOnWriteArrayList<Element> list = new CopyOnWriteArrayList<>();
	MyTank mt;
	EnemyTank et1;
	EnemyTank et2;

	public GameWindow(String title, int width, int height, int fps) {
		super(title, width, height, fps);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onCreate() {
		// TODO Auto-generated method stub
		try {
			SoundUtils.play("res/snd/start.wav");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//砖墙
		for(int i=1;i<config.WIDTH/64 - 1;i++) {
			Wall wall = new Wall(i*64, 64);
			//list.add(wall);
			addElment(wall);
		}
		//水墙
		for(int i=1;i<config.WIDTH/64 - 1 ;i++) {
			Water water = new Water(i*64, 64*3);
			//list.add(water);
			addElment(water);
		}
		//砖墙
		for(int i=0;i<config.WIDTH/64 -11;i++) {
			Wall wall = new Wall(i*64, 64*5);
			//list.add(wall);
			addElment(wall);
		}
		//铁墙
		for(int i=5;i<config.WIDTH/64 - 8;i++) {
			Steel steel = new Steel(i*64, 64*5);
			//list.add(steel);
			addElment(steel);
		}
		//铁墙
		for(int i=9;i<config.WIDTH/64 ;i++) {
			Steel steel = new Steel(i*64, 64*5);
			//list.add(steel);
			addElment(steel);
		}
		//草坪
		for(int i=1;i<config.WIDTH/64 - 1;i++) {
			Grass grass = new Grass(i*64, 64*7);
			//list.add(grass);
			addElment(grass);
		}
		
		//砖墙
		for(int i=1;i<config.WIDTH/64 - 10;i++) {
			Wall wall = new Wall(i*64, 64*10);
			//list.add(wall);
			addElment(wall);
		}
		//砖墙
		for(int i=6;i<config.WIDTH/64 - 5;i++) {
			Wall wall = new Wall(i*64, 64*10);
			//list.add(wall);
			addElment(wall);
		}
		//砖墙
		for(int i=11;i<config.WIDTH/64 ;i++) {
			Wall wall = new Wall(i*64, 64*10);
			//list.add(wall);
			addElment(wall);
		}
		//草坪
    	for(int i=1;i<config.WIDTH/64 - 1;i++) {
			Grass grass = new Grass(i*64, 64*8);
			//list.add(grass);
			addElment(grass);
		}
		//绘制坦克
		mt = new MyTank(config.WIDTH/2-32, config.HEIGHT-64);
		//list.add(mt);
		addElment(mt);
		
		et1 = new EnemyTank(0, 0);
		et2 = new EnemyTank(config.WIDTH - 64, 0);
	}

	@Override
	protected void onMouseEvent(int key, int x, int y) {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void onKeyEvent(int key) {
		// TODO Auto-generated method stub
		switch (key) {
		case Keyboard.KEY_UP:
			mt.move(Direction.UP);
			break;
		case Keyboard.KEY_DOWN:
			mt.move(Direction.DOWN);
			break;
		case Keyboard.KEY_LEFT:
			mt.move(Direction.LEFT);
			break;
		case Keyboard.KEY_RIGHT:
			mt.move(Direction.RIGHT);
			break;
		case Keyboard.KEY_RETURN:
			ZiDan shot = mt.shot();
			if (shot != null) {
				//list.add(shot);
				addElment(shot);
			}
		default:
			break;
		}
			
	}

	@Override
	protected void onDisplayUpdate() {
		// TODO Auto-generated method stub
		for(Element a : list) {
			a.draw();
		}
		
		//调用敌方坦克
		for(Element e1 : list) {
			if (e1 instanceof EnemyTank) {
				((EnemyTank)e1).move();
				ZiDan shot = ((EnemyTank)e1).shot();
				addElment(shot);
			}
		}
		/*//销毁出界子弹
		for(Element e1 : list) {
			//遍历是子弹是否需要销毁
			if(e1 instanceof ZiDan) {
				boolean flag = ((ZiDan)e1).isDestroy();
				if(flag) {
					list.remove(e1);
				}
			}
		}
		//销毁爆炸物
		for(Element e1 : list) {
			if(e1 instanceof Blast) {
				boolean flag = ((Blast)e1).isDestory();
				if (flag) {
					list.remove(e1);
				}
			}
		}
		//销毁铁墙
		for(Element e1 : list) {
			if(e1 instanceof Steel) {
				boolean flag = ((Steel)e1).isDestory();
				if (flag) {
					list.remove(e1);
				}
			}
		}*/
		//System.out.println(list.size());
		//销毁出界子弹
	    for(Element e1 : list) {
	    	//遍历是子弹是否需要销毁
	    	if(e1 instanceof ZiDan) {
	    		boolean flag = ((ZiDan)e1).isDestroy();
				if(flag) {
					list.remove(e1);
				}
			}
		}
		//校验坦克和铁墙是否撞上
		for(Element e1 : list) {
			for(Element e2 : list) {
				if(e1 instanceof Moveable && e2 instanceof Blockable) {
					//能走到这，说明e1是坦克 ，e2是铁墙
					boolean flag = ((Moveable)e1).checkHit((Blockable)e2);
					if (flag) {//flag = true  说明撞上
						break;
					}
				}
			
			}
		}
		//子弹与铁墙，
		//具有攻击能力与具有挨打能力的
		for(Element e1 : list) {
			for(Element e2 : list) {
				if(e1 instanceof Attackable && e2 instanceof Hitable) {
					//能走到这，说明e1是子弹 ，e2是铁墙
					boolean flag = ((Attackable)e1).checkAttack((Hitable)e2);
					if (flag) {//flag = true  说明撞上
						//关于子弹：消失
						list.remove(e1);
						//关于铁墙：响应
						Blast blast = ((Hitable)e2).showAttack();
						addElment(blast);
						
					}
				}
			
			}
		}
		//销毁事物
		for (Element e1 : list) {
			//判断是否需要销毁
			if (e1 instanceof Destroyable) {
			     boolean blast = ((Destroyable)e1).isDestroyed();
			     if (blast) {
					Blast blast2 = ((Blast)e1).showDestory();
					if (blast2 != null) {
						addElment(blast2);
					}
					list.remove(e1);
				}
			}
			
		}
		
	}

    public void addElment(Element e) {
    	list.add(e);
    	
    	list.sort(new Comparator<Element>() {

			@Override
			public int compare(Element e1, Element e2) {
				// TODO Auto-generated method stub
				return e1.getOrder() - e2.getOrder();
			}
		});;
    }
}
