package jk_game;

public interface config {
      String TITLE = "坦克大战";
      int WIDTH = 64 * 15;
      int HEIGHT = 64 * 13;
      int FPS = 50;
}
