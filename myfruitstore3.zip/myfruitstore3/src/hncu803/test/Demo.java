package hncu803.test;

import hncu803_view.AdminDialog;
import hncu803_view.MainFrame;

/*
 * ������
 */
public class Demo {
	public static void main(String[] args) {
		//new MainFrame().setVisible(true);
		new AdminDialog().setVisible(true);
	}
}
