package hncu803.test;

import java.io.IOException;
import java.sql.Connection;

import hncu803_dao.AdminDao;
import hncu803_domain.FruitItem;
import hncu803_tools.JDBCUtils;

public class JDBCTest {
	public static void main(String[] args)throws Exception {
		/*Connection con = JDBCUtils.getConnection();
		System.out.println(con);*/
		
		AdminDao ad = new AdminDao();
		FruitItem fruitItem = new FruitItem("4","����",15.5,"kg");
		ad.addFruitItem(fruitItem);
		
	}
}
