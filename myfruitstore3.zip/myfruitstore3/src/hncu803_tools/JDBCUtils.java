package hncu803_tools;
/*
 * �����Ҫʵ��
 *  1 ��ȡ���ݿ������
 *  2 �ͷ���Դ
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCUtils {
	//��ȡ���Ӷ���
	public static Connection getConnection()throws Exception {
		// 1. ע��������ʹ�õ��Ƿ��似������������ûѧ��ֻ�ܼ�ס��
		Class.forName("com.mysql.jdbc.Driver");

		// 2. ��ȡ����
		// public static Connection getConnection(String url,String user,String
		// password)
		String url = "jdbc:mysql://localhost:3306/mybase";
		String user = "root";
		String password = "123";

		Connection con = DriverManager.getConnection(url, user, password);
		
		return con;
	}
	
	//�ͷ���Դ
	public static void release(Statement stat, Connection con) {
		if(stat!=null) {
			try {
				stat.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void release(Statement stat, Connection con, ResultSet rs) {
		if(stat!=null) {
			try {
				stat.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	} 
}
