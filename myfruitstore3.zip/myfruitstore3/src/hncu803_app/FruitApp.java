package hncu803_app;

import hncu803_view.MainFrame;

public class FruitApp {
	public static void main(String[] args) {
		new MainFrame().setVisible(true);
	}
}
