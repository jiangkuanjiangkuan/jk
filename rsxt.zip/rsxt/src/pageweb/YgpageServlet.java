package pageweb;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Yg;
import pageservice.YgpageService;
import pageservice.impl.YgpageServiceImpl;
import service.YgService;
import service.impl.YgServiceImpl;
import vo.PageBean;

public class YgpageServlet extends HttpServlet {
    private YgpageService ygpageservice = new YgpageServiceImpl();
    private YgService ygservice = new YgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//当前页为第一页
		String ygPage = request.getParameter("dqpage");
		
		if (ygPage==null) {
			ygPage="1";
		}
		int dqpage = Integer.parseInt(ygPage);
		//认为每页显示6条
		int dqnumpage = 10;
		
		PageBean<Yg> pageBean = null;
		try {
			pageBean = ygpageservice.findPageBean(dqpage,dqnumpage);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//1.调用service查询所有的信息
		/*List<Yg> ygchalist = ygservice.getygall();
		//2.将信息列表放入request域中
		request.setAttribute("ygchalist", ygchalist);
		for(Yg a: ygchalist) {
			String name = a.getYg_sex();
			System.out.println(name);
		}*/
		
		request.setAttribute("pageBean", pageBean);
		request.getRequestDispatcher("/rslist.jsp").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
