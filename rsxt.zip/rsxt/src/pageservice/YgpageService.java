package pageservice;

import java.sql.SQLException;

import domain.Yg;
import vo.PageBean;

public interface YgpageService {

	PageBean<Yg> findPageBean(int dqpage, int dqnumpage) throws SQLException;

}
