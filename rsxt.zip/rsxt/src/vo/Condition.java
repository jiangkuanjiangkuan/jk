package vo;

public class Condition {
	
	private String yg_position;  
	private String yg_eduction;
	public String getYg_position() {
		return yg_position;
	}
	public void setYg_position(String yg_position) {
		this.yg_position = yg_position;
	}
	public String getYg_eduction() {
		return yg_eduction;
	}
	public void setYg_eduction(String yg_eduction) {
		this.yg_eduction = yg_eduction;
	}
	@Override
	public String toString() {
		return "Condition [yg_position=" + yg_position + ", yg_eduction=" + yg_eduction + "]";
	}  
	
	

}
