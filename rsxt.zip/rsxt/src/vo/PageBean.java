package vo;

import java.util.ArrayList;
import java.util.List;

import domain.Yg;

public class PageBean<T> {
	
	//当前页
	private int dqpage;
	//当前页显示的条数
	private int dqnumpage;
	//总条数
	private int numpage;
	//总页数
	private int page;
	//获得每页显示的数据
	private  List<T> mylist = new ArrayList<T>();
	
	
	
	public int getDqpage() {
		return dqpage;
	}
	public void setDqpage(int dqpage) {
		this.dqpage = dqpage;
	}
	public int getDqnumpage() {
		return dqnumpage;
	}
	public void setDqnumpage(int dqnumpage) {
		this.dqnumpage = dqnumpage;
	}
	public int getNumpage() {
		return numpage;
	}
	public void setNumpage(int numpage) {
		this.numpage = numpage;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public List<T> getMylist() {
		return mylist;
	}
	public void setMylist(List<T> mylist) {
		this.mylist = mylist;
	}
	

	
	
	
}
