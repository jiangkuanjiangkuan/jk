package register;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import domain.Gl;
import service.GlService;
import service.YgService;
import service.impl.GlServiceImpl;


public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private GlService glservice = new GlServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");	
		//获取客户端信息
		String gl_password = request.getParameter("gl_password");
		System.out.println(gl_password);
		//注冊并保存
		Gl gl = new Gl();
		try {
			BeanUtils.populate(gl, request.getParameterMap());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(gl);
		glservice.save_2(gl);
		
		//根据密码查询
		Gl glxinxi = null;
		try {
			glxinxi = glservice.chagl(gl_password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		request.setAttribute("glxinxi", glxinxi);
		
		//输出全部
		List<Gl> glchalist = glservice.getglall();
		request.setAttribute("glchalist", glchalist);
		
		
		System.out.println(glchalist);
		//重定向到列表
		//response转发
		//request重定向
		request.getRequestDispatcher("/Zhuce.jsp").forward(request, response);
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
