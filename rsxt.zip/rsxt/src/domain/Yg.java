package domain;

public class Yg {
	private int yg_id;
	private String yg_name;
	private String yg_password;
	private String yg_sex;
	private String yg_age;
	private String yg_position;
	private String yg_eduction;
	private String yg_email;
	private String yg_address;
	private String yg_time;
	private String yg_gongzi;
	private String yg_jianli;
	private String yg_photo;
	
	
	public int getYg_id() {
		return yg_id;
	}
	public void setYg_id(int yg_id) {
		this.yg_id = yg_id;
	}
	public String getYg_name() {
		return yg_name;
	}
	public void setYg_name(String yg_name) {
		this.yg_name = yg_name;
	}
	public String getYg_password() {
		return yg_password;
	}
	public void setYg_password(String yg_password) {
		this.yg_password = yg_password;
	}
	public String getYg_sex() {
		return yg_sex;
	}
	public void setYg_sex(String yg_sex) {
		this.yg_sex = yg_sex;
	}
	public String getYg_age() {
		return yg_age;
	}
	public void setYg_age(String yg_age) {
		this.yg_age = yg_age;
	}
	public String getYg_position() {
		return yg_position;
	}
	public void setYg_position(String yg_position) {
		this.yg_position = yg_position;
	}
	public String getYg_eduction() {
		return yg_eduction;
	}
	public void setYg_eduction(String yg_eduction) {
		this.yg_eduction = yg_eduction;
	}
	public String getYg_email() {
		return yg_email;
	}
	public void setYg_email(String yg_email) {
		this.yg_email = yg_email;
	}
	public String getYg_address() {
		return yg_address;
	}
	public void setYg_address(String yg_address) {
		this.yg_address = yg_address;
	}
	public String getYg_gongzi() {
		return yg_gongzi;
	}
	public void setYg_gongzi(String yg_gongzi) {
		this.yg_gongzi = yg_gongzi;
	}
	public String getYg_time() {
		return yg_time;
	}
	public void setYg_time(String yg_time) {
		this.yg_time = yg_time;
	}
	public String getYg_jianli() {
		return yg_jianli;
	}
	public void setYg_jianli(String yg_jianli) {
		this.yg_jianli = yg_jianli;
	}
	public String getYg_photo() {
		return yg_photo;
	}
	public void setYg_photo(String yg_photo) {
		this.yg_photo = yg_photo;
	}
	@Override
	public String toString() {
		return "Yg [yg_id=" + yg_id + ", yg_name=" + yg_name + ", yg_password=" + yg_password + ", yg_sex=" + yg_sex
				+ ", yg_age=" + yg_age + ", yg_position=" + yg_position + ", yg_eduction=" + yg_eduction + ", yg_email="
				+ yg_email + ", yg_address=" + yg_address + ", yg_time=" + yg_time + ", yg_gongzi=" + yg_gongzi
				+ ", yg_jianli=" + yg_jianli + ", yg_photo=" + yg_photo + "]";
	}
	
	
	

}
