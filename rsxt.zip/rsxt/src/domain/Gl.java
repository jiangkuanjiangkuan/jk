package domain;

public class Gl {
	private int gl_id;
	private String gl_name;
	private String gl_password;
	private String gl_sex;
	private String gl_age;
	private String gl_position;
	private String gl_eduction;
	private String gl_email;
	private String gl_address;
	
	public int getGl_id() {
		return gl_id;
	}
	public void setGl_id(int gl_id) {
		this.gl_id = gl_id;
	}
	public String getGl_name() {
		return gl_name;
	}
	public void setGl_name(String gl_name) {
		this.gl_name = gl_name;
	}
	public String getGl_password() {
		return gl_password;
	}
	public void setGl_password(String gl_password) {
		this.gl_password = gl_password;
	}
	public String getGl_sex() {
		return gl_sex;
	}
	public void setGl_sex(String gl_sex) {
		this.gl_sex = gl_sex;
	}
	public String getGl_age() {
		return gl_age;
	}
	public void setGl_age(String gl_age) {
		this.gl_age = gl_age;
	}
	public String getGl_position() {
		return gl_position;
	}
	public void setGl_position(String gl_position) {
		this.gl_position = gl_position;
	}
	public String getGl_eduction() {
		return gl_eduction;
	}
	public void setGl_eduction(String gl_eduction) {
		this.gl_eduction = gl_eduction;
	}
	public String getGl_email() {
		return gl_email;
	}
	public void setGl_email(String gl_email) {
		this.gl_email = gl_email;
	}
	public String getGl_address() {
		return gl_address;
	}
	public void setGl_address(String gl_address) {
		this.gl_address = gl_address;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Gl [gl_id=").append(gl_id).append(", gl_name=").append(gl_name).append(", gl_password=")
				.append(gl_password).append(", gl_sex=").append(gl_sex).append(", gl_age=").append(gl_age)
				.append(", gl_position=").append(gl_position).append(", gl_eduction=").append(gl_eduction)
				.append(", gl_email=").append(gl_email).append(", gl_address=").append(gl_address).append("]");
		return builder.toString();
	}
	
	
	
	
}
