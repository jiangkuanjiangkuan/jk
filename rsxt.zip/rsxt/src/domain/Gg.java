package domain;

import org.omg.Messaging.SyncScopeHelper;

public class Gg {
	private int gg_id;
	private String gg_name;
	private String gg_zhuti;
	private String gg_word;
	private String gg_time;
	public int getGg_id() {
		return gg_id;
	}
	public void setGg_id(int gg_id) {
		this.gg_id = gg_id;
	}
	public String getGg_name() {
		return gg_name;
	}
	public void setGg_name(String gg_name) {
		this.gg_name = gg_name;
	}
	public String getGg_word() {
		return gg_word;
	}
	public void setGg_word(String gg_word) {
		this.gg_word = gg_word;
	}
	public String getGg_time() {
		return gg_time;
	}
	public void setGg_time(String gg_time) {
		this.gg_time = gg_time;
	}
	
	public String getGg_zhuti() {
		return gg_zhuti;
	}
	public void setGg_zhuti(String gg_zhuti) {
		this.gg_zhuti = gg_zhuti;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Gg [gg_id=").append(gg_id).append(", gg_name=").append(gg_name).append(", gg_zhuti=")
				.append(gg_zhuti).append(", gg_word=").append(gg_word).append(", gg_time=").append(gg_time).append("]");
		return builder.toString();
	}

	
	
}
