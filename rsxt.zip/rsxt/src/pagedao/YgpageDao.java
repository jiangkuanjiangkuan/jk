package pagedao;

import java.sql.SQLException;
import java.util.List;

import domain.Yg;

public interface YgpageDao {

	int getNumpage() throws SQLException;

	List<Yg> findpagexinxi(int index, int dqnumpage) throws SQLException;

}
