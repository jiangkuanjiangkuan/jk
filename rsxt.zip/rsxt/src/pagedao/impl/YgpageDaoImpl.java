package pagedao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

import domain.Yg;
import pagedao.YgpageDao;
import utlis.DataSourceUtils;

public class YgpageDaoImpl implements YgpageDao {
	
	//获得全部的员工总人数
	@Override
	public int getNumpage() throws SQLException {
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select count(*) from yg";
		Long query = (Long) runner.query(sql, new ScalarHandler());
		return query.intValue();
	}

	@Override
	public List<Yg> findpagexinxi(int index, int dqnumpage) throws SQLException {
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from yg limit ?,? ";
		return runner.query(sql, new BeanListHandler<Yg>(Yg.class),index,dqnumpage);
	}

}
