package dao;

import java.sql.SQLException;
import java.util.List;

import domain.Gg;

public interface GgDao {

	void save_3(Gg gg);

	List<Gg> getggall();

	Gg chagg(String gg_zhuti) throws SQLException;

}
