package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;


import dao.GgDao;
import domain.Gg;
import domain.Yg;
import utlis.DataSourceUtils;
import utlis.HibernateUtils;

public class GgDaoImpl implements GgDao {

	@Override
	public void save_3(Gg gg) {
		// TODO Auto-generated method stub
		//获取
		Session session = HibernateUtils.openSession();
			
		//打开事务
		Transaction transaction = session.beginTransaction();
		//执行保存
		session.save(gg);
				
		//提交事务
		transaction.commit();
				
		//关闭资源
		session.close();
	}

	@Override
	public List<Gg> getggall() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		
		Criteria criteria = session.createCriteria(Gg.class);
		List<Gg> list = criteria.list();
		for(Gg gg:list) {
			System.out.println("fgfgsgfb"+gg.getGg_name());
		}
		return list;
	}

	@Override
	public Gg chagg(String gg_zhuti) throws SQLException {
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from gg where gg_zhuti=?";
		Gg ggxinxi = runner.query(sql, new BeanHandler<Gg>(Gg.class),gg_zhuti);
		return ggxinxi;
	}

}
