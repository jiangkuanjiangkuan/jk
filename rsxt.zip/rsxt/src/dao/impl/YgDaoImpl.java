 package dao.impl;

import java.beans.Customizer;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import dao.YgDao;
import domain.Gl;
import domain.Yg;
import utlis.DataSourceUtils;
import utlis.HibernateUtils;
import vo.Condition;

public class YgDaoImpl implements YgDao {

	public void save_1(Yg yg) {
		//获取
		Session session = HibernateUtils.openSession();
		//打开事务
		Transaction transaction = session.beginTransaction();
		//执行保存
		session.save(yg);
		//提交事务
		transaction.commit();
		//关闭资源
		session.close();
	}

	public List<Yg> getygall() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		
		Criteria criteria = session.createCriteria(Yg.class);
		List<Yg> list = criteria.list();
		for(Yg yg:list) {
			System.out.println("fgfgsgfb"+yg.getYg_name());
		}
		return list;
	}

	@Override
	public void delyg(String yg_password) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "delete from yg where yg_password=?";
		runner.update(sql, yg_password);
		
	}

	@Override
	public List<Yg> getygdellist() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		Criteria criteria = session.createCriteria(Yg.class);
		
		List<Yg> ygdellist = criteria.list();
		
		for(Yg yg:ygdellist) {
			System.out.println("11111"+yg.getYg_age());
			
		}
		return ygdellist;
	}

	@Override
	public Yg chayg(String yg_password) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "select * from yg where yg_password=?";
		Yg ygxinxi = runner.query(sql, new BeanHandler<Yg>(Yg.class), yg_password);
		return ygxinxi;
		
		/*Session session = HibernateUtils.getCurrentSession();
		Criteria criteria = session.createCriteria(Yg.class);
		
		criteria.add(Restrictions.eq("yg_password",yg_password));
		
		Yg ygxinxi = (Yg) criteria.uniqueResult();
		System.out.println(ygxinxi);
		return ygxinxi;*/
	}

	@Override
	public Yg getygchalist() {
		Session session = HibernateUtils.getCurrentSession();
		Criteria criteria = session.createCriteria(Yg.class);
		
		Yg ygchalist = (Yg) criteria.list();
		

		System.out.println("2222"+ygchalist.getYg_email());
		
		return ygchalist;
	}

	@Override
	public void ygupdate(Yg yg) throws SQLException {
		/*// TODO Auto-generated method stub
		//获取
		Session session = HibernateUtils.openSession();
		//打开事务
		Transaction transaction = session.beginTransaction();
		//执行保存修改
		session.update(yg);
		//提交事务
		transaction.commit();
		//关闭资源
		session.close();*/
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		String sql = "update yg set yg_name=?,yg_sex=?,yg_age=?,yg_position=?,yg_eduction=?,yg_email=?,yg_address=?,yg_time=?,yg_gongzi=?,yg_jianli=?,yg_photo=? where yg_password=?";
		runner.update(sql,yg.getYg_name(),yg.getYg_sex(),yg.getYg_age(),yg.getYg_position(),yg.getYg_eduction(),yg.getYg_email(),yg.getYg_address()
				,yg.getYg_time(),yg.getYg_gongzi(),yg.getYg_jianli(),yg.getYg_photo(),yg.getYg_password());
	}

	@Override
	public List<Yg> chazw_and_bm(Condition condition) throws SQLException {
		// TODO Auto-generated method stub
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		//定义一个存储实际参数的容器
		List<String> yglist = new ArrayList<String>();
		
		String sql = "select * from yg where 1=1";
		if (condition.getYg_eduction()!=null&&!condition.getYg_eduction().trim().equals("")||condition.getYg_eduction()=="0") {
			sql+=" and yg_eduction = ? ";
			yglist.add(condition.getYg_eduction().trim());
		}
		if (condition.getYg_position()!=null&&!condition.getYg_position().trim().equals("")||condition.getYg_position()=="0") {
			sql+=" and yg_position = ? ";
			yglist.add(condition.getYg_position().trim());
		}
		
		List<Yg> list = runner.query(sql, new BeanListHandler<Yg>(Yg.class), yglist.toArray());
		
		for(Yg yg : list) {
			System.out.println("职位与部门查询"+yg.getYg_age());
			
		}
		return list ;
	}
	
	
	
	
	
	
	
	

}
