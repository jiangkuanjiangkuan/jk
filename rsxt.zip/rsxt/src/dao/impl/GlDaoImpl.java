package dao.impl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.GlDao;
import domain.Gl;
import domain.Yg;
import utlis.DataSourceUtils;
import utlis.HibernateUtils;

public class GlDaoImpl implements GlDao {

	@Override
	public void save_2(Gl gl) {
		// TODO Auto-generated method stub
		//获取
		Session session = HibernateUtils.openSession();	
		//打开事务
		Transaction transaction = session.beginTransaction();
		//执行保存
		session.save(gl);
		//提交事务
		transaction.commit();
		//关闭资源
		session.close();
	}

	@Override
	public List<Gl> getglall() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		Criteria criteria = session.createCriteria(Gl.class);
		List<Gl> list = criteria.list();
		for(Gl gl:list) {
			System.out.println("f888888"+gl.getGl_position());
		}
		return list;
	}

	@Override
	public Gl chagl(String gl_password) {
		Session session = HibernateUtils.openSession();
		Transaction tx = session.beginTransaction();
		
		//执行HQL查询操作
		//1书写HQL语句
		String hql = "from gl ";//查询GL所有对象
		//2创建查询对象
		Query query = session.createQuery(hql);
		
		//3获得查询结果
		//Gl list = query.list();
		//query.uniqueResult();接收唯一的查询结果
		
		//System.out.println(list);
		//return list;
		tx.commit();
		session.close();
		return null;
		
		
	}

}
