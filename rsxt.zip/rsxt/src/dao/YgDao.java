package dao;

import java.sql.SQLException;
import java.util.List;

import domain.Yg;
import vo.Condition;

public interface YgDao {

	void save_1(Yg yg);

	List<Yg> getygall();

	void delyg(String yg_password) throws SQLException;

	List<Yg> getygdellist();

	Yg chayg(String yg_password) throws SQLException;

	Yg getygchalist();

	void ygupdate(Yg yg) throws SQLException;

	List<Yg> chazw_and_bm(Condition condition) throws SQLException;

	
	

}
