package dao;

import java.sql.SQLException;
import java.util.List;

import domain.Gl;

public interface GlDao {

	void save_2(Gl gl);

	List<Gl> getglall();

	Gl chagl(String gl_password) throws SQLException;

}
