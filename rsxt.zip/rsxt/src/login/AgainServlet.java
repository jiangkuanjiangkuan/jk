package login;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import domain.Gl;
import utlis.DataSourceUtils;

public class AgainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		String gl_password = request.getParameter("gl_password");
		System.out.println(gl_password);
		
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		
		String sql = "select * from gl where gl_password=?";
		
		Gl gl_1 = null;
		
		try {
			gl_1 = runner.query(sql, new BeanHandler<Gl>(Gl.class),gl_password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if (gl_1!=null) {
			response.sendRedirect(request.getContextPath()+"/ygadd.jsp");
			
		} else {
			response.sendRedirect(request.getContextPath()+"/Zhuye.jsp");
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
