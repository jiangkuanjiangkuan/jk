package login;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;


import domain.Yg;
import service.YgService;
import service.impl.YgServiceImpl;
import utlis.DataSourceUtils;

public class LoginServlet extends HttpServlet {
	private YgService ygservice = new YgServiceImpl();

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		
		String yg_name = request.getParameter("yg_name");
		String yg_password = request.getParameter("yg_password");
		
		System.out.println(yg_name);
		
		QueryRunner runner = new QueryRunner(DataSourceUtils.getDataSource());
		
		String sql= "select * from yg where yg_name=? and yg_password=?";
		
		Yg yg = null;
		try {
			yg = runner.query(sql, new BeanHandler<Yg>(Yg.class), yg_name,yg_password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*//1.调用service查询所有的信息
				List<Yg> denglu = ygservice.getygall();
				//2.将信息列表放入request域中
				request.setAttribute("denglu", denglu);*/
		if (yg!=null) {
				request.getSession().setAttribute(yg_name, yg_password);
				response.sendRedirect(request.getContextPath()+"/Zhuye.jsp");
				
		} else {
				response.sendRedirect(request.getContextPath()+"/Denglu.jsp");
		}
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
