package service;

import java.sql.SQLException;
import java.util.List;

import domain.Gl;

public interface GlService {

	void save_2(Gl gl);

	List<Gl> getglall();

	Gl chagl(String gl_password) throws SQLException;

}
