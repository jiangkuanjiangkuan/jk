package service.impl;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.GlDao;
import dao.impl.GlDaoImpl;
import domain.Gl;
import service.GlService;
import utlis.HibernateUtils;

public class GlServiceImpl implements GlService {
	private GlDao gldao = new GlDaoImpl();

	public void save_2(Gl gl) {
		// TODO Auto-generated method stub
		gldao.save_2(gl);
	}
	@Override
	public List<Gl> getglall() {
		// TODO Auto-generated method stub
		return gldao.getglall();
	}
	@Override
	public Gl chagl(String gl_password) throws SQLException {
		// TODO Auto-generated method stub
		return gldao.chagl(gl_password);
	}

}
