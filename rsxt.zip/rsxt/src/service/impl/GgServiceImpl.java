package service.impl;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.GgDao;
import dao.impl.GgDaoImpl;
import domain.Gg;
import service.GgService;
import utlis.HibernateUtils;

public class GgServiceImpl implements GgService {
	private GgDao ggdao = new GgDaoImpl();
	@Override
	public void save_3(Gg gg) {
		// TODO Auto-generated method stub
		ggdao.save_3(gg);
	}
	@Override
	public List<Gg> getggall() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		
		List<Gg> ggList = ggdao.getggall();
		transaction.commit();
		return ggList;
	}
	@Override
	public Gg chagg(String gg_zhuti) throws SQLException {
		// TODO Auto-generated method stub
		return ggdao.chagg(gg_zhuti);
	}

}
