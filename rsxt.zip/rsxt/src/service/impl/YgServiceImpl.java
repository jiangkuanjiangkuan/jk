package service.impl;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import dao.YgDao;
import dao.impl.YgDaoImpl;
import domain.Yg;
import service.YgService;
import utlis.HibernateUtils;
import vo.Condition;

public class YgServiceImpl implements YgService {
	private YgDao ygdao = new YgDaoImpl();
	
	public void save_1(Yg yg) {
		// TODO Auto-generated method stub
		ygdao.save_1(yg);
	}
	@Override
	public List<Yg> getygall() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		
		Transaction transaction = session.beginTransaction();
		
		List<Yg> yglist = ygdao.getygall();
		transaction.commit();
		return yglist;
	}
	@Override
	public void delyg(String yg_password) throws SQLException {
		// TODO Auto-generated method stub
		ygdao.delyg(yg_password);
		
	}
	@Override
	public List<Yg> getygdellist() {
		// TODO Auto-generated method stub
		Session session = HibernateUtils.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		
		List<Yg> ygdellist = ygdao.getygdellist();
		transaction.commit();
		return ygdellist;
	}
	@Override
	public Yg chayg(String yg_password) throws SQLException {
		// TODO Auto-generated method stub
		return ygdao.chayg(yg_password);
	}
	
	@Override
	public Yg getygchalist() {
		Session session = HibernateUtils.getCurrentSession();
		Transaction transaction = session.beginTransaction();
		
		Yg ygchalist = ygdao.getygchalist();
		transaction.commit();
		return ygchalist;
	}
	@Override
	public void ygupdate(Yg yg) throws SQLException {
		// TODO Auto-generated method stub
		ygdao.ygupdate(yg);
	}
	@Override
	public List<Yg> chazw_and_bm(Condition condition) throws SQLException {
		// TODO Auto-generated method stub
		return ygdao.chazw_and_bm(condition);
	}


}
