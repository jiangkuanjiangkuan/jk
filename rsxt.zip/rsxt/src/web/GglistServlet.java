package web;

import java.io.IOException;
import java.util.Calendar;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.boot.model.source.internal.hbm.ModelBinder;

import domain.Gg;
import service.GgService;
import service.impl.GgServiceImpl;

public class GglistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private GgService ggservice = new GgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		
		//1.调用service查询所有的信息
		List<Gg> ggxinxi = ggservice.getggall();
		//2.将信息列表放入request域中
		request.setAttribute("ggList", ggxinxi);
		
		for(Gg b:ggxinxi) {
			String name=b.getGg_name();
			System.out.println(name);
		}
		
		request.getRequestDispatcher("/shouye/Dongtai.jsp").forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
