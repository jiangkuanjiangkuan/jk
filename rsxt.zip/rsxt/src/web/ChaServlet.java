package web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import domain.Gl;
import domain.Yg;
import service.GlService;
import service.YgService;
import service.impl.GlServiceImpl;
import service.impl.YgServiceImpl;
import vo.Condition;

public class ChaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YgService ygservice = new YgServiceImpl();
	private GlService glservice = new GlServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		
		
//员工账号查询
		//获取
		String yg_password = request.getParameter("yg_password"); 
		
		System.out.println(yg_password);
		//调用方法查询
		Yg ygxinxi = null;
		try {
			ygxinxi=ygservice.chayg(yg_password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//1.调用service查询所有的信息
		List<Yg> ygchalist = ygservice.getygall();
		//2.将信息列表放入request域中
		request.setAttribute("ygchalist", ygchalist);
		request.setAttribute("ygxinxi", ygxinxi);
		
		System.out.println(ygxinxi);
		
		
		//重定向
		//request.getRequestDispatcher("/rslist.jsp").forward(request, response);
		
		
//职位与部门查询
			
			
		request.getRequestDispatcher("/ygupdate.jsp").forward(request, response);
		
	
		
		//response.sendRedirect(request.getContextPath()+"/ChalistServlet");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
