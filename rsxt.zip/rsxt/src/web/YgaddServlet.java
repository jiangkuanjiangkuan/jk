package web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import domain.Yg;
import service.YgService;
import service.impl.YgServiceImpl;

public class YgaddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YgService ygservice = new YgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");	
		//获取客户端信息
		String yg_password = request.getParameter("yg_password"); 
		System.out.println(yg_password);
		
		Yg yg = new Yg();
		try {
			BeanUtils.populate(yg, request.getParameterMap());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(yg);
		ygservice.save_1(yg);
		
		//回写
		Yg ygxinxi = null;
		
		try {
			ygxinxi=ygservice.chayg(yg_password);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		//1.调用service查询所有的信息
		List<Yg> ygchalist = ygservice.getygall();
		//2.将信息列表放入request域中
		request.setAttribute("ygchalist", ygchalist);
		request.setAttribute("ygxinxi", ygxinxi);
		System.out.println(ygxinxi);
		
		
		
		request.getRequestDispatcher("/ygadd.jsp").forward(request, response);
		
		//重定向到列表
		//response转发
		//request重定向
		//request.getRequestDispatcher("/YglistServlet").forward(request, response);
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
