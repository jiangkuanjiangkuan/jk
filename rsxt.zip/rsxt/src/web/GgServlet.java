package web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import domain.Gg;
import domain.Yg;
import service.GgService;
import service.impl.GgServiceImpl;

public class GgServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private GgService ggservice = new GgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");	
		//获取客户端信息
		
		
		Gg gg = new Gg();
		try {
			BeanUtils.populate(gg, request.getParameterMap());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(gg);
		ggservice.save_3(gg);
		
		
		String gg_zhuti = request.getParameter("gg_zhuti");
		System.out.println(gg_zhuti);
		Gg ggxinxi = null;
		
		try {
			ggxinxi = ggservice.chagg(gg_zhuti);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//1.调用service查询所有的信息
		List<Gg> ggchalist = ggservice.getggall();
		//2.将信息列表放入request域中
		request.setAttribute("ggchalist", ggchalist);
		request.setAttribute("ggxinxi", ggxinxi);
		System.out.println(ggxinxi);
		//重定向到列表
		//response转发
		//request重定向
		request.getRequestDispatcher("/gonggao.jsp").forward(request, response);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
