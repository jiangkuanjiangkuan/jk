package web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import domain.Yg;
import service.YgService;
import service.impl.YgServiceImpl;
import vo.Condition;


public class ChalistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YgService ygservice = new YgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		
		//1、收集表单数据
		Map<String, String[]> properties = request.getParameterMap();
		 //遍历  
		  for(Iterator iter=properties.entrySet().iterator();iter.hasNext();){  
		        Map.Entry element=(Map.Entry)iter.next();  
		        //key值  
		        Object strKey = element.getKey();  
		        //value,数组形式  
		      String[] value=(String[])element.getValue();  
		  
		     System.out.print(strKey.toString() +"=");  
		     for(int i=0;i<value.length;i++){  
		         System.out.print(value[i]);  
		     }             
		  }
		  
		  
		//2、将散装的查询数据封装到一个VO实体中
		Condition condition = new Condition();
		try {
			BeanUtils.populate(condition, properties);
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		//3、将实体传递给service层
		List<Yg> yglist = null;
		
		try {
			yglist = ygservice.chazw_and_bm(condition);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//准备商品类别
		//获得所有的商品的类别数据
		/*//1.调用service查询所有的信息
		List<Yg> ygchalist = ygservice.getygall();
		//2.将信息列表放入request域中
		request.setAttribute("ygchalist", ygchalist);*/
		
		
		request.setAttribute("condition",condition);
		request.setAttribute("yglist", yglist);
		
		for(Yg b:yglist) {
			
			String name = b.getYg_eduction();
			System.out.println("职位与部门查询-"+name);
		}
		
		

		request.getRequestDispatcher("/bmfirst.jsp").forward(request, response);
		
		
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
