package web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import domain.Yg;
import service.YgService;
import service.impl.YgServiceImpl;

public class YgdellistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YgService ygservice = new YgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		//1.调用service查询所有的信息
		List<Yg> ygdellist = ygservice.getygdellist();
		//2.将信息列表放入request域中
		request.setAttribute("ygdellist", ygdellist);
		//遍历
		for(Yg b:ygdellist) {
			String name = b.getYg_email();
			System.out.println(name);
		}
		
		request.getRequestDispatcher("/ygupdate.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
