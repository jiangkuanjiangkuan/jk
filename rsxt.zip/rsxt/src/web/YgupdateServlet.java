package web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import domain.Yg;
import service.YgService;
import service.impl.YgServiceImpl;

public class YgupdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private YgService ygservice = new YgServiceImpl();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");	
		
		Yg ygxinxi = new Yg();
		try {
			BeanUtils.populate(ygxinxi, request.getParameterMap());
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(ygxinxi);
		
		try {
			ygservice.ygupdate(ygxinxi);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//1.调用service查询所有的信息
		List<Yg> ygchalist = ygservice.getygall();
		//2.将信息列表放入request域中
		request.setAttribute("ygchalist", ygchalist);
		request.setAttribute("ygxinxi", ygxinxi);
		System.out.println(ygxinxi);
		request.getRequestDispatcher("/ygupdate.jsp").forward(request, response);
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
