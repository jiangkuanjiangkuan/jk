package com.jk.service;

import com.jk.bean.Admin;
import com.jk.dao.AdminDao;

public class AdminService {
	AdminDao adminDao = new AdminDao();
	
	public Admin getAdminByname(String name){
		Admin admin = adminDao.getAdminByname(name);
		System.out.println("Service:"+admin.getName());
		return admin;
	}
//	判断手机号是否存在
	public Admin getAdminByphone(String phone){
//		调dao中方法
		Admin admin = adminDao.getAdminByphone(phone);
		return admin;
	}
}
