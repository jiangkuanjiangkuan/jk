package com.jk.util;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;
import org.apache.commons.dbutils.handlers.BeanListHandler;
import org.apache.commons.dbutils.handlers.ScalarHandler;

//使用dbutils封装了通用增删改查
public class BaseDao<T> {
	private QueryRunner qr=new QueryRunner();
	private Class type;//type解释T的具体类型
	//获取泛型的类型
	public BaseDao() {
		//获取子类
		Class class1 = this.getClass();
		//通过子类获取父类
		//使用ParameterizedType获取带有泛型的父类
		ParameterizedType superclass = (ParameterizedType) class1.getGenericSuperclass();
		//获取泛型的类型
		Type[] types = superclass.getActualTypeArguments();
		this.type=(Class) types[0];
	}
	//1.封装通用增删改
	public int update(Connection connection,String sql,Object...objects) {
		int update=0;
		try {
			update = qr.update(connection, sql, objects);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return update;
	}
	//2.封装通用查询（查询单条）
	public T getBean(Connection connection,String sql,Object...objects) {
		T t =null;
		try {
			BeanHandler<T> bh=new BeanHandler<T>(type);
			t = qr.query(connection, sql, bh, objects);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return t;
	}
	
	//3.封装通用查询（查询多条）
	public List<T> getBeanList(Connection connection,String sql,Object...objects) {
		List<T> list =null;
		try {
			BeanListHandler<T> bh=new BeanListHandler<T>(type);
			list = qr.query(connection, sql, bh, objects);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	//4.查询单个数据的，比如使用聚合函数的时候，返回的是单个数据
	public Object getSingleValue(Connection connection,String sql,Object...objects) {
		ScalarHandler sh=new ScalarHandler();
		Object object =null;
		try {
			object = qr.query(connection,sql,sh,objects);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return object;
	}
}
