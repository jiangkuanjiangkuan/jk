package com.jk.dao;

import java.sql.Connection;
import java.util.List;

import com.jk.bean.Admin;
import com.jk.util.BaseDao;
import com.jk.util.JdbcUtils;

import sun.net.idn.Punycode;

public class AdminDao extends BaseDao<Admin>{
//	登入
	public Admin loginAdminDao(String name,String password){
		Connection connection = JdbcUtils.getConnection();
		String sql = "select * from admin where name=? and password=?";
		Admin admin = getBean(connection, sql, name,password);
		JdbcUtils.closeConnection(connection);
		return admin;
	}
	
//	注册
	public int registerAdminDao(String name, String password,String email,String posion,String phone){
		
		Connection connection = JdbcUtils.getConnection();
		String sql = "insert into admin (name, password, email, posion, phone,time)"+"value(?,?,?,?,?,now())";
		Object[] objects = {name, password, email, posion, phone};
		int register = update(connection, sql, objects);
		JdbcUtils.closeConnection(connection);
		return register;
	}
	
	public List<Admin> listAdminDao(){
		Connection connection = JdbcUtils.getConnection();
		String sql  = "select * from admin";
		List<Admin> list  = getBeanList(connection, sql, null);
		for(Admin admin : list){
			System.out.println(admin);
		}
		JdbcUtils.closeConnection(connection);
		
		return list;
	}
	
//	判断账号是否存在
	public Admin getAdminByname(String name){
		Connection connection = JdbcUtils.getConnection();
		String sql = "select * from admin where name=?";
		
		System.out.println(name);
		
		Admin admin = getBean(connection, sql, name);
		JdbcUtils.closeConnection(connection);
		return admin;
	}
//	判断手机号是否存在
	public Admin getAdminByphone(String phone){
		Connection connection = JdbcUtils.getConnection();
		String sql = "select * from admin where phone=?";
		Admin admin = getBean(connection, sql, phone);
		JdbcUtils.closeConnection(connection);
		return admin;
	}
	
	public static void main(String[] args) {
//		Connection connection = JdbcUtils.getConnection();
//		System.out.println(connection);
		
		AdminDao adminDao = new AdminDao();
		
		/*Admin admin = adminDao.loginAdminDao("a", "1");
		System.out.println(admin);
		*/
		
//		List<Admin> list = adminDao.listAdminDao();
		/*for(Admin admin : list){
			System.out.println(admin.getName());
		}*/
		
		Admin admin1 = adminDao.getAdminByname("aaaaaaaa");
	}
	
	
}
