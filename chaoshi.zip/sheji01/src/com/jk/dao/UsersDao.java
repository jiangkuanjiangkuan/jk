package com.jk.dao;

import java.sql.Connection;

import com.jk.bean.Users;
import com.jk.util.BaseDao;
import com.jk.util.JdbcUtils;

public class UsersDao extends BaseDao<Users>{
		
		public Users LoginUsersDao(String name, String password){
			
			Connection connection = JdbcUtils.getConnection();
			String sql = "select * from users where name=? and password=?";
			Users users = getBean(connection, sql, name,password);
			
			System.out.println(name);
			
			JdbcUtils.closeConnection(connection);
			return users;
		}
		
		
		public int reginsterDao(String name,String password){
			
			Connection connection = JdbcUtils.getConnection();
			String sql = "insert into users (name,password,createTime)"+"value(?,?,now())";
			Object[] objects = {name,password};
			int reginsterusers = update(connection, sql, objects);
			JdbcUtils.closeConnection(connection);
			return reginsterusers;
			
		}
		
		
		
		
		
		public static void main(String[] args) {
			/*Connection connection = JdbcUtils.getConnection();
			System.out.println(connection);*/
			
			UsersDao usersDao = new UsersDao();
			Users users = usersDao.LoginUsersDao("1", "1");
			System.out.println(users);
			
			
			
		}
}
