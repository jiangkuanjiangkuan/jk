package com.jk.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.jk.bean.Admin;

import com.jk.dao.AdminDao;
import com.jk.service.AdminService;
import com.jk.util.BaseServlet;

@WebServlet("/AdminServlet")
public class AdminServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
	private AdminDao adminDao = new AdminDao();
	//注册和登入、列表没用service
    public AdminServlet() {
        super();
    }

	protected void doAdminlogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		String name = request.getParameter("name");
		String password  = request.getParameter("password");
		
		System.out.println(name);
		
		Admin adminlogin = adminDao.loginAdminDao(name, password);
		
		if(adminlogin!=null){
			request.getSession().setAttribute("adminsession", adminlogin);
			response.sendRedirect(request.getContextPath()+"/admin/index.jsp");
		}else {
			request.getSession().setAttribute("msg", "登入失败");
			response.sendRedirect(request.getContextPath()+"/admin/login.jsp");
		}
	}
	

	protected void doAdminRgister(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String name  = request.getParameter("name");
		String password  = request.getParameter("password");
		String email  = request.getParameter("email");
		String posion  = request.getParameter("posion");
		String phone  = request.getParameter("phone");
		
		System.out.println(name);
		
		int adminreginster = adminDao.registerAdminDao(name, password, email, posion, phone);
		
		if(adminreginster>0){
			request.getSession().setAttribute("msg", "注册成功");
			response.sendRedirect(request.getContextPath()+"/admin/index.jsp");
		}else{
			request.getSession().setAttribute("msg", "登入失败");
			response.sendRedirect(request.getContextPath()+"/admin/login.jsp");
		}
	}
	
	
	protected void doListAdmin(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		List<Admin> list = adminDao.listAdminDao();
		
		for(Admin admin : list){
			System.out.println(admin.getName());
		}
		
		request.setCharacterEncoding("utf-8");
		//请求前台传过来的请求参数
//		String info = request.getParameter("info");
//		System.out.println(info);
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter writer = response.getWriter();
		
		ObjectMapper oMapper = new ObjectMapper();
		String jsonlist = oMapper.writeValueAsString(list);
		System.out.println(jsonlist);
		writer.print(jsonlist);

	}
	
	
//	判断账号是否存在
	protected void dogetAdminByname(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		AdminService adminService = new AdminService();
		PrintWriter pWriter = response.getWriter();
		String name = request.getParameter("name");
		
		System.out.println("页面："+name);
		
		Admin admin = adminService.getAdminByname(name);
		if(admin==null){
			//可以注册
			pWriter.print(true);
		}else{
			//账号已存在
			pWriter.print(false);
		}
		
	}
	

	protected void dogetAdminByphone(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		AdminService adminService = new AdminService();
//		创建响应流对象
		PrintWriter writer = response.getWriter();
//		获取页面数据
		String phone  = request.getParameter("phone");
//		调用userService中的方法
		Admin admin = adminService.getAdminByphone(phone);
		if(admin==null){
//			可以注册
			writer.print(true);
		}else{
//			手机号已存在
			writer.print(false);
		}
	}


}
