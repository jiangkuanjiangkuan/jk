package com.jk.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jk.bean.Users;
import com.jk.dao.UsersDao;
import com.jk.util.BaseServlet;

@WebServlet("/UsersServlet")
public class UsersServlet extends BaseServlet{
	private static final long serialVersionUID = 1L;
    
    public UsersServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doLoginUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		UsersDao usersDao = new UsersDao();
		
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		
		System.out.println(name);
		
		Users loginusersdao = usersDao.LoginUsersDao(name, password);
		
//		4页面跳转
		if(loginusersdao!=null){
			request.getSession().setAttribute("usersSession", loginusersdao);
			response.sendRedirect(request.getContextPath()+"/common/home-1.jsp");
		}else{
			request.getSession().setAttribute("msg", "登录失败");
			response.sendRedirect(request.getContextPath()+"/common/signin-up.jsp");
		}
	}

}
