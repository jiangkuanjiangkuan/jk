# -*- coding:utf-8 -*-
from django.apps import AppConfig


class OrganizationConfig(AppConfig):
    name = 'organization'
    verbose_name = u"机构管理"