# -*- coding:utf-8 -*-
# 将apps设置加入引用
default_app_config = "courses.apps.CoursesConfig"