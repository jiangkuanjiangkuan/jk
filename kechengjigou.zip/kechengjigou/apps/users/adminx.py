#!/usr/bin/env python 
# -*- coding:utf-8 -*-

import xadmin
from xadmin import views
from datetime import datetime
from .models import EmailVerifyRecord, Banner, UserProfile
from xadmin import views
from xadmin.plugins.auth import UserAdmin


# 基础配置 全局配置
class BaseSetting(object):
    # 主题功能
    enable_themes = True
    use_bootswatch = True


class GlobalSettings(object):
    site_title = u"书城在线后台管理系统"
    site_footer = u"书城在线网"
    # 收缩app
    menu_style = "accordion"


# 邮箱验证码注册
class EmailVerifyRecordAdmin(object):
    # xadmin显示列
    list_display = ['code', 'email', 'send_type', 'send_time']
    # xadmin显示搜索
    search_fields = ['code', 'email', 'send_type']
    # xadmin显示过滤器
    list_filter = ['code', 'email', 'send_type', 'send_time']


# 轮播图注册
class BannerAdmin(object):
    list_display = ['title', 'image', 'url', 'index', 'add_time']
    search_fields = ['title', 'image', 'url', 'index']
    list_filter = ['title', 'image', 'url', 'index', 'add_time']


# 关联注册
xadmin.site.register(EmailVerifyRecord, EmailVerifyRecordAdmin)
xadmin.site.register(Banner, BannerAdmin)
# 主题注册
xadmin.site.register(views.BaseAdminView, BaseSetting)
# 界面部分设置
xadmin.site.register(views.CommAdminView, GlobalSettings)